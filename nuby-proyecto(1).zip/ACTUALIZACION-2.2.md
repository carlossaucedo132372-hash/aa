# Nuby AI 2.2 – Cielo nocturno

Integración sobre el ZIP original 1.6 enviado por el usuario. No es una app independiente. Se conserva `com.nuby.asistente`, la firma de prueba original, el prefijo de datos `nuby2-`, el Worker, el cliente Gemini, los recordatorios y las notificaciones nativas.

## Actualizar desde el celular
1. En la app instalada, Ajustes > Copiar respaldo. Guárdalo en privado. No desinstales la app ni borres sus datos.
2. En el MISMO repositorio de GitHub que compiló la app actual, sustituye el ZIP anterior por `nuby-proyecto.zip`. Deja un solo ZIP en la raíz. Si tu repo tiene el proyecto descomprimido, debes actualizar esos archivos en lugar de agregar un ZIP.
3. Si deseas que el nombre de APK indique 2.2, reemplaza `.github/workflows/build-apk.yml` por el incluido en este ZIP (también se entrega por separado). El workflow anterior puede funcionar si reconoce el ZIP, pero el nombre de la descarga podría mostrar una versión anterior.
4. En Actions comprueba que termina con éxito. En Releases descarga el APK y actualiza encima del actual. Si Android muestra conflicto de firma o versión, no desinstales: revisa el repositorio, firma y versionCode.
5. En Nuby comprueba Ajustes > Probar conexión. No necesitas cambiar los secretos de Cloudflare si la configuración anterior se conservó.

## Cambios
- Navegación lateral izquierda, sin pestañas inferiores ni tarjetas de navegación duplicadas.
- Una mascota principal con cara SVG modular y 32 estados, parpadeo, movimiento, reacciones al toque. Introducción con la misma estética y transición CSS. Lectura por voz con movimiento aproximado de boca (no sincronización fonética), dictado si el WebView lo permite.
- Historial de chats archivados (hasta 40), recuerdos manuales locales (hasta 100). Estos recuerdos no se envían a Gemini. Cada chat activo mantiene hasta 100 mensajes como antes.
- Guía educativa local de 56 fichas y el mismo importador original de MedlinePlus en español y etiquetas openFDA en inglés; los catálogos dependen de que la descarga en GitHub Actions funcione. No se ofrece diagnóstico, receta ni cálculo de dosis. Contenido local pendiente de revisión médica profesional.

## Verificación y límites
Pasaron las comprobaciones de sintaxis de JavaScript, los IDs únicos y los archivos originales sin cambios (Worker, Gemini, notificaciones, recordatorios, almacenamiento, firma, configuración Capacitor). Se generó la biblioteca en modo offline. El navegador del entorno bloqueó la ejecución, por lo que no se completaron pruebas interactivas ni compilación APK. No se verificaron Gemini real, notificaciones nativas, reconocimiento/lectura por voz ni rendimiento a 60 FPS en Android. Conserva el respaldo y prueba antes de depender de esta edición.
